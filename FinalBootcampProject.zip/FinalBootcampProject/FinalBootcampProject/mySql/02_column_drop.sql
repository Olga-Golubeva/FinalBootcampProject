ALTER TABLE `bootcamp_final_project`.`objects_data`
DROP COLUMN `objects_image`;
